public interface DogService {
	void sleep();
}
